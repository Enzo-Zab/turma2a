
function botão1(){
    
    var alunos = document.getElementById("alunos").value
    var bombons = alunos * 2 + 1
    
    
document.getElementById("resposta").innerHTML ="A escola terá que comprar "+bombons+" bombons para a turma"

}
